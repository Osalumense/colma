/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
var XLSX_1 = require('../../xlsx.js');
var XLSX_2 = require('../../dist/xlsx.core.min.js');
var XLSX_3 = require('../../dist/xlsx.full.min.js');
var XLSX_N = require('xlsx');
